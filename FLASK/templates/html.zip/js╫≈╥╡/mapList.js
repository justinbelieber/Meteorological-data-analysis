﻿get([
    {
        "AreaName": "上海",
        "sum": 1246951.5
    },
    {
        "AreaName": "湖北",
        "sum": 642083.1
    },
    {
        "AreaName": "北京",
        "sum": 451473.6
    },
    {
        "AreaName": "广东",
        "sum": 408654.9
    },
    {
        "AreaName": "湖南",
        "sum": 307711
    },
    {
        "AreaName": "天津",
        "sum": 241009
    },
    {
        "AreaName": "四川",
        "sum": 206745.5
    },
    {
        "AreaName": "云南",
        "sum": 163192.7
    },
    {
        "AreaName": "山东",
        "sum": 54687
    },
    {
        "AreaName": "浙江",
        "sum": 32725
    },
    {
        "AreaName": "江苏",
        "sum": 32470
    }
])